"""
ntree - A modern and feature-rich replacement for the Linux `tree` command.
"""

__version__ = "0.1.1" # FileExist bug fix
__author__ = "Vijay Satheesh"
__license__ = "MIT"